#!/usr/bin/python

print "Content-Type: text/plain\r\n\r\n"

print "Codigo de errores:\n\n"

print "ERROR:01 => 'no se han encontrado datos del usuario'\n"
print "ERROR:02 => 'El servidor de genteguada no esta levantado'\n"
print "ERROR:03 => 'el regalo no se pudo eliminar debiado a un error'\n"
print "ERROR:04 => 'el jugador no se pudo eliminar debiado a un error'\n"

